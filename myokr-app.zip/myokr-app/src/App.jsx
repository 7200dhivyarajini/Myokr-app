// src/App.jsx
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import AddOKR from './pages/Addokr';
import Login from './pages/login';
import Signup from './pages/signup';
import Dashboard from './pages/Dashboard';
import EmployeeDashboard from './pages/EmployeeDashboard'; // ✅ Step 1: Import

function App() {
  return (
    <Router>
      {/* 🔗 Tailwind-based Navigation */}
      <nav className="bg-gray-800 text-white p-4 flex justify-between items-center">
        <h1 className="font-bold text-lg">🚀 MyOKR</h1>
        <div className="flex gap-4">
          <Link to="/" className="hover:underline">🏠 Home</Link>
          <Link to="/login" className="hover:underline">🔐 Login</Link>
          <Link to="/signup" className="hover:underline">📝 Signup</Link>
        </div>
      </nav>

      {/* 🧭 Routes */}
      <Routes>
        <Route path="/" element={<AddOKR />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/employee-dashboard" element={<EmployeeDashboard />} /> {/* ✅ Step 2: Add this */}
      </Routes>
    </Router>
  );
}

export default App;
