import React from "react";

const Progress = ({ value = 0, label }) => {
  return (
    <div className="w-full space-y-1">
      {label && (
        <div className="text-sm font-medium text-gray-700 flex justify-between">
          <span>{label}</span>
          <span>{value}%</span>
        </div>
      )}
      <div className="w-full bg-gray-300 rounded-full h-4 overflow-hidden">
        <div
          className="bg-blue-600 h-full transition-all duration-500"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
};

export default Progress;
