// src/firebase.js

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getAnalytics, isSupported } from "firebase/analytics";

// 🔐 Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyB2GitYIBm5cSPRv_0xoAk8_yTFONLa5mU",
  authDomain: "myokr-bff79.firebaseapp.com",
  projectId: "myokr-bff79",
  storageBucket: "myokr-bff79.appspot.com",
  messagingSenderId: "977669819773",
  appId: "1:977669819773:web:b964f8a90c578fda3dd014",
  measurementId: "G-ZVVFBFMJGQ",
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);

// ✅ Exports
export const db = getFirestore(app);
export const auth = getAuth(app);

// ✅ Optional Analytics
let analytics;
isSupported().then((supported) => {
  if (supported) {
    analytics = getAnalytics(app);
  }
});
