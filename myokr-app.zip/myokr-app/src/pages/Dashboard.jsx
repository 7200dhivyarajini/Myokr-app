// top of your file
import React, { useState, useEffect } from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { LinearProgress, Box, Typography } from "@mui/material";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
} from "firebase/auth";
import { auth, db } from "../firebase";
import {
  doc,
  setDoc,
  getDoc,
  collection,
  getDocs,
} from "firebase/firestore";

// ✅ Import background image
import backgroundImage from "../assets/download.jpeg";

const Dashboard = () => {
  const [metrics, setMetrics] = useState({
    timeline: 28,
    milestones: 55,
    objectives: 33,
    confidence: 40,
  });

  const [hrDetails, setHrDetails] = useState({
    name: "",
    email: "",
    department: "",
  });

  const [employees, setEmployees] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUserId(user.uid);

        const adminRef = doc(db, "admins", user.uid);
        const adminSnap = await getDoc(adminRef);
        if (adminSnap.exists()) {
          setHrDetails(adminSnap.data());
        }

        const usersSnapshot = await getDocs(collection(db, "users"));
        const usersList = usersSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setEmployees(usersList);
        setShowForm(true);
      }
    });

    return () => unsubscribe();
  }, []);

  // ... all the rest of your handlers remain unchanged

  const metricStyle = { width: 100, height: 100 };

  return (
    <div
      className="min-h-screen bg-cover bg-center text-gray-800 p-6"
      style={{
        backgroundImage: `url(${backgroundImage})`,
      }}
    >
      <div className="bg-white bg-opacity-90 backdrop-blur-md rounded-2xl shadow-lg p-4">
        <h1 className="text-4xl font-bold text-center mb-10 text-indigo-800 drop-shadow-md">
          Admin Dashboard - MyOKR
        </h1>

        {/* ✅ Everything from here inside remains as-is */}
        {/* HR/Admin Details */}
        <div className="bg-white shadow-lg p-6 rounded-xl mb-8 max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-pink-600 text-center mb-4">HR/Admin Details</h2>
          <div className="flex flex-col gap-4">
            <input
              type="text"
              placeholder="Full Name"
              className="p-2 bg-pink-50 text-gray-900 rounded border border-gray-300 text-center"
              value={hrDetails.name}
              onChange={(e) => setHrDetails({ ...hrDetails, name: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email"
              className="p-2 bg-pink-50 text-gray-900 rounded border border-gray-300 text-center"
              value={hrDetails.email}
              onChange={(e) => setHrDetails({ ...hrDetails, email: e.target.value })}
            />
            <input
              type="text"
              placeholder="Department"
              className="p-2 bg-pink-50 text-gray-900 rounded border border-gray-300 text-center"
              value={hrDetails.department}
              onChange={(e) =>
                setHrDetails({ ...hrDetails, department: e.target.value })
              }
            />
          </div>
        </div>

        {/* ⬇️ Leave the rest of the code as you already wrote */}
        {/* Metrics */}
        {/* Employee Form */}
        {/* Submit Buttons */}
      </div>
    </div>
  );
};

export default Dashboard;
