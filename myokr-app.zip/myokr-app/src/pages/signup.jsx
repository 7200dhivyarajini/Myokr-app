import React, { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';
import Navbar from "../components/Navbar";

const Signup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSignup = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      alert('✅ Signup successful');
      navigate('/dashboard'); // HR goes to Dashboard
    } catch (err) {
      alert('❌ ' + err.message);
    }
  };

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-[#eaf2ff] flex justify-center items-center">
        <div className="w-full max-w-md px-8">
          <h1 className="text-4xl font-bold mb-8 text-black text-center">
            Sign Up
          </h1>

          <form onSubmit={(e) => e.preventDefault()} className="flex flex-col items-center">
            {/* Email */}
            <div className="w-[400px] mb-6">
              <label className="block text-md text-black mb-2">Email</label>
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-[50px] text-lg px-6 text-black placeholder-gray-400 bg-white border border-gray-300 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>

            {/* Password */}
            <div className="w-[400px] mb-10">
              <label className="block text-md text-black mb-2">Password</label>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-[50px] text-lg px-6 text-black placeholder-gray-400 bg-white border border-gray-300 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>

            {/* Sign Up Button */}
            <button
              onClick={handleSignup}
              className="w-[150px] bg-[#2f80ed] text-white text-md font-medium py-3 rounded-md shadow-sm hover:bg-[#1c6ed8] transition"
            >
              Sign Up
            </button>

            <hr className="my-6 border-gray-300 w-[400px]" />

            <div className="text-center">
              <p className="text-sm text-blue-700 font-medium">
                Already have an account?{" "}
                <a href="/login" className="hover:underline">
                  Log in here.
                </a>
              </p>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Signup;
