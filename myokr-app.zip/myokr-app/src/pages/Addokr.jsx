import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import {
  FaPlusCircle,
  FaTachometerAlt,
  FaUserShield,
  FaShieldAlt,
} from "react-icons/fa";

// ✅ Import background image from local assets
import backgroundImage from "../assets/download.jpeg";

const AddOKR = () => {
  const navigate = useNavigate();

  const features = [
    {
      title: "Add OKR",
      desc: "Define your objectives and key results for clear goal setting.",
      icon: <FaPlusCircle size={32} className="text-indigo-600" />,
      action: () => navigate("/signup"), // 👈 Redirecting to signup
      color: "bg-indigo-100",
    },
    {
      title: "Track Progress",
      desc: "Monitor your OKR progress with visual insights and performance bars.",
      icon: <FaTachometerAlt size={32} className="text-rose-600" />,
      action: () => navigate("/signup"), // 👈 Redirecting to signup
      color: "bg-rose-100",
    },
    {
      title: "HR/Admin Dashboard",
      desc: "Manage employees, assign OKRs, and monitor progress centrally.",
      icon: <FaUserShield size={32} className="text-emerald-600" />,
      action: () => navigate("/signup"), // 👈 Redirecting to signup
      color: "bg-emerald-100",
    },
    {
      title: "Secure Login",
      desc: "Access your role-specific dashboard securely with protected login.",
      icon: <FaShieldAlt size={32} className="text-yellow-600" />,
      action: () => navigate("/signup"), // 👈 Redirecting to signup
      color: "bg-yellow-100",
    },
  ];

  return (
    <>
      <Navbar />
      <div
        className="min-h-screen bg-cover bg-center flex flex-col items-center justify-center px-4 pt-24"
        style={{
          backgroundImage: `url(${backgroundImage})`,
        }}
      >
        <div className="bg-white bg-opacity-90 backdrop-blur-md rounded-2xl p-10 shadow-2xl w-full max-w-5xl">
          <h1 className="text-4xl md:text-5xl font-bold text-center text-indigo-800 mb-10 drop-shadow-lg">
            🚀 Welcome to <span className="text-pink-600">MyOKR</span> Platform
          </h1>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                onClick={feature.action}
                className={`cursor-pointer transition-transform duration-300 transform hover:scale-105 hover:shadow-2xl ${feature.color} p-6 rounded-xl shadow-md border border-gray-300`}
              >
                <div className="flex flex-col items-center space-y-3 text-center">
                  <div className="p-3 bg-white rounded-full shadow">{feature.icon}</div>
                  <h3 className="text-xl font-semibold text-indigo-800">
                    {feature.title}
                  </h3>
                  <p className="text-gray-700 text-sm">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AddOKR;
