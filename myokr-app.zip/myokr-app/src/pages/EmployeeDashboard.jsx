import React, { useEffect, useState } from "react";
import { auth, db } from "../firebase";
import { doc, getDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

// ✅ Import background image from assets
import backgroundImage from "../assets/download.jpeg";

const EmployeeDashboard = () => {
  const [userData, setUserData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      const user = auth.currentUser;

      if (!user) {
        navigate("/login");
        return;
      }

      const docRef = doc(db, "users", user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setUserData({
          ...docSnap.data(),
          email: user.email,
        });
      } else {
        alert("User data not found.");
      }
    };

    fetchUserData();
  }, [navigate]);

  if (!userData) {
    return <div className="text-center mt-10 text-gray-500">Loading your dashboard...</div>;
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-6"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="max-w-4xl mx-auto bg-white bg-opacity-90 backdrop-blur-md p-8 rounded-xl shadow-lg">
        <h1 className="text-3xl font-bold text-indigo-700 mb-2">🎯 Welcome, {userData.email}</h1>
        <p className="text-gray-600 mb-6">
          Department: <span className="font-medium">{userData.department || "N/A"}</span>
        </p>

        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Your Objectives</h2>

        {userData.objectives && userData.objectives.length > 0 ? (
          <div className="space-y-8">
            {userData.objectives.map((obj, index) => (
              <div key={index} className="bg-gray-100 p-6 rounded-lg shadow-md">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gray-700">{obj.title || "Untitled Objective"}</h3>
                  <div style={{ width: 60, height: 60 }}>
                    <CircularProgressbar
                      value={obj.percentage}
                      text={`${obj.percentage}%`}
                      styles={buildStyles({
                        textSize: "30px",
                        pathColor: obj.percentage >= 80 ? "#22c55e" : obj.percentage >= 50 ? "#facc15" : "#ef4444",
                        textColor: "#1e293b",
                        trailColor: "#e5e7eb",
                      })}
                    />
                  </div>
                </div>

                <div className="w-full h-4 bg-gray-300 rounded-full overflow-hidden mb-4">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      obj.percentage >= 80
                        ? "bg-green-500"
                        : obj.percentage >= 50
                        ? "bg-yellow-400"
                        : "bg-red-500"
                    }`}
                    style={{ width: `${obj.percentage}%` }}
                  ></div>
                </div>

                <div>
                  <p className="font-semibold text-sm text-gray-600 mb-1">Key Results:</p>
                  <ul className="list-disc pl-5 text-sm text-gray-700">
                    {obj.keyResults && obj.keyResults.length > 0 ? (
                      obj.keyResults.map((kr, krIndex) => <li key={krIndex}>{kr}</li>)
                    ) : (
                      <li>No key results listed.</li>
                    )}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">You have no objectives assigned yet.</p>
        )}
      </div>
    </div>
  );
};

export default EmployeeDashboard;
