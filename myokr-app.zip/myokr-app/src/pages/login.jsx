import React, { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { getDoc, doc } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  // Password strength validation
  const isStrongPassword = (pwd) => {
    const regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=])[A-Za-z\d!@#$%^&*()_\-+=]{8,}$/;
    return regex.test(pwd);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!isStrongPassword(password)) {
      alert(
        "❌ Password must contain:\n- 1 uppercase letter\n- 1 lowercase letter\n- 1 number\n- 1 special character\n- At least 8 characters long"
      );
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Check in 'users' collection
      const userDoc = await getDoc(doc(db, "users", user.uid));

      if (userDoc.exists()) {
        navigate("/employee-dashboard");
        alert("✅ Login successful (Employee)");
        return;
      }

      // Check in 'admins' collection
      const adminDoc = await getDoc(doc(db, "admins", user.uid));

      if (adminDoc.exists()) {
        navigate("/dashboard");
        alert("✅ Login successful (HR/Admin)");
        return;
      }

      // If neither document exists
      alert("❌ User not found in Firestore");
    } catch (error) {
      alert("❌ Login failed: " + error.message);
    }
  };

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-[#eaf2ff] flex justify-center items-center">
        <div className="w-full max-w-md px-8">
          <h1 className="text-4xl font-bold mb-8 text-black text-center">
            Welcome.
          </h1>

          <form onSubmit={handleLogin} className="flex flex-col items-center">
            {/* Email */}
            <div className="w-[400px] mb-6">
              <label className="block text-md text-black mb-2">Email</label>
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-[50px] text-lg px-6 text-black placeholder-gray-400 bg-white border border-gray-300 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>

            {/* Password */}
            <div className="w-[400px] mb-10">
              <label className="block text-md text-black mb-2">Password</label>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-[50px] text-lg px-6 text-black placeholder-gray-400 bg-white border border-gray-300 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>

            {/* Login Button */}
            <button
              type="submit"
              className="w-[150px] bg-[#2f80ed] text-white text-md font-medium py-3 rounded-md shadow-sm hover:bg-[#1c6ed8] transition"
            >
              Log In
            </button>

            {/* Extra Links */}
            <div className="text-center text-sm text-black space-y-2 mt-6">
              <p className="cursor-pointer hover:underline">
                Forgot password (returning users)
              </p>
              <p className="cursor-pointer hover:underline">
                Resend email verification link (new users)
              </p>
            </div>

            <hr className="my-6 border-gray-300 w-[400px]" />

            <div className="text-center">
              <p className="text-sm text-blue-700 font-medium">
                New?{" "}
                <a href="/signup" className="hover:underline">
                  Sign up for an account.
                </a>
              </p>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Login;
